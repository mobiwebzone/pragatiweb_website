<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$username = $_SESSION['username'] ?? '';
$email = $_SESSION['email'] ?? '';
?>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Admin Dashboard</a>

    <div class="collapse navbar-collapse" id="navbarNavDropdown">
      <ul class="navbar-nav ms-auto">
        <!-- 🔹 User Management Menu -->
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="userMgmtDropdown" role="button" data-bs-toggle="dropdown">
            User Management
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="create_user_with_grid.php">Create New User</a></li>
            <li><a class="dropdown-item" href="create_roles_with_grid.php">Create New Role</a></li>
            <li><a class="dropdown-item" href="create_menus_with_grid.php">Create New Menu</a></li>
            <li><a class="dropdown-item" href="assign_menu_to_role.php">Assign Menus to Role</a></li>
            <li><a class="dropdown-item" href="assign_role_to_user.php">Assign Role to User</a></li>
          </ul>
        </li>

        <!-- 🔹 Enquiry Management Menu -->
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle enquiry-menu" href="#" id="enquiryMgmtDropdown" role="button" data-bs-toggle="dropdown">
            Enquiry Management
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="enquiry_details.php">Enquiry Details</a></li>
          </ul>
        </li>
      </ul>
    </div>

    <!-- 👤 User Toggle Button -->
    <button class="user-toggle" onclick="toggleSidebar(event)">
      👤 <?php echo htmlspecialchars($username); ?>
    </button>
  </div>
</nav>
